from abc import ABC, abstractmethod
from typing import Optional
from langchain_core.embeddings import Embeddings
from langchain_community.chat_models.tongyi import BaseChatModel,ChatTongyi
from langchain_community.embeddings import DashScopeEmbeddings
from utils.config_handler import rag_conf

class BaseModelFactory(ABC):
    @abstractmethod
    def generator(self)->Optional[Embeddings|BaseChatModel]:
        pass
    
    
class SmartChatModelFactory(BaseModelFactory):
    def generator(self)->Optional[Embeddings|BaseChatModel]:
        return ChatTongyi(model=rag_conf['smart_chat_model_name'])
    
class CheapChatModelFactory(BaseModelFactory):
    def generator(self)->Optional[Embeddings|BaseChatModel]:
        return ChatTongyi(model=rag_conf['cheap_chat_model_name'])
    
class EmbeddingModelFactory(BaseModelFactory):
    def generator(self)->Optional[Embeddings|BaseChatModel]:
        return DashScopeEmbeddings(model=rag_conf['embedding_model_name'])
    
smart_chat_model= SmartChatModelFactory().generator()
cheap_chat_model= CheapChatModelFactory().generator()
embedding_model= EmbeddingModelFactory().generator()