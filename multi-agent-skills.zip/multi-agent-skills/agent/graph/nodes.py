from langchain_core.messages import SystemMessage
from model.factory import smart_chat_model
from skills.registry import SKILL_REGISTRY
import datetime


_LLM_WITH_TOOLS_CACHE = {}


def get_llm_with_tools(skill_name: str, skill_tools: list):
    """
    懒加载 bind_tools。

    第一次用到某个 skill 时才 bind_tools。
    后面复用缓存。
    """
    if skill_name not in _LLM_WITH_TOOLS_CACHE:
        _LLM_WITH_TOOLS_CACHE[skill_name] = smart_chat_model.bind_tools(skill_tools)

    return _LLM_WITH_TOOLS_CACHE[skill_name]


def agent_node(state):
    """
    通用 Agent 节点。

    根据 router 写入的 state["main_skill"] 动态选择 Skill。
    """
    skill_name = state.get("main_skill")

    if not skill_name:
        raise ValueError("state 中缺少 main_skill，router 可能没有正确写入。")

    if skill_name not in SKILL_REGISTRY:
        raise ValueError(f"未知 main_skill: {skill_name}")

    skill_spec = SKILL_REGISTRY[skill_name]

    # 运行时加载当前 skill 的 system prompt
    system_prompt = skill_spec.load_text()

    if getattr(skill_spec, "needs_time_context", False):
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        system_prompt += f"\n\n[System Note: 真实时间 {current_time}。"
        system_prompt += "对于今天/最新/最近类信息，不得直接复用旧结果，必须使用工具重新获取。]"

    # 第一次用到这个 skill 时才 bind_tools
    llm_with_tools = get_llm_with_tools(
        skill_name=skill_name,
        skill_tools=skill_spec.tools,
    )

    messages = [SystemMessage(content=system_prompt)] + state["messages"]

    response = llm_with_tools.invoke(messages)

    return {
        "messages": [response],
        "current_agent": skill_name,
    }