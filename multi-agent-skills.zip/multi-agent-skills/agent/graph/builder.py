from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode
from agent.graph.state import AgentState
from agent.graph.nodes import agent_node
from skills.registry import SKILL_REGISTRY
from agent.graph.router import router_node
import sqlite3
from langgraph.checkpoint.sqlite import SqliteSaver
from utils.path_tool import get_abs_path


def tools_condition(state: AgentState):
    """
    判断是否需要调用工具。
    """
    last_message = state["messages"][-1]

    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
        return "tools"

    return END


def build_multi_agent_graph():
    builder = StateGraph(AgentState)

    # 1. 路由节点：只负责判断 main_skill
    builder.add_node("router", router_node)

    # 2. 统一 Agent 节点：运行时根据 main_skill 选择 Skill
    builder.add_node("agent", agent_node)

    # 3. 统一工具节点：包含所有已注册工具
    from skills.skills_tools import all_registered_tools
    builder.add_node("tools", ToolNode(all_registered_tools()))

    # 4. 边
    builder.add_edge(START, "router")
    builder.add_edge("router", "agent")

    # 5. agent 执行完后，判断是否调用工具
    builder.add_conditional_edges(
        "agent",
        tools_condition,
        {
            "tools": "tools",
            "__end__": END,
        },
    )

    # 6. 工具执行完后，回到 agent
    builder.add_edge("tools", "agent")

    # 7. sqlite 会话记忆
    conn = sqlite3.connect(
        get_abs_path("datas/chat_multi_history.db"),
        check_same_thread=False,
    )
    memory = SqliteSaver(conn)

    graph = builder.compile(checkpointer=memory)

    return graph, conn, memory