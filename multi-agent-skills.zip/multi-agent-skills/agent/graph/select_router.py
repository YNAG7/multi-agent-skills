from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field

from utils.prompt_loader import load_router_prompt
from model.factory import cheap_chat_model
from skills.skills_tools import format_skill_map, get_available_skills


# 只保留 main skill
main_skills_dict = get_available_skills()
main_block = format_skill_map(main_skills_dict)
main_names = ", ".join(main_skills_dict.keys())

# 动态构造主 skill 枚举
MainSkillEnum = Enum(
    "MainSkillEnum",
    {k: k for k in main_skills_dict.keys()}
)


class SkillRoute(BaseModel):
    main_skill: MainSkillEnum = Field(
        ...,
        description="本轮任务唯一选择的主 skill"
    )

    reason: str = Field(
        ...,
        description="简要说明为什么选择这个 skill，方便调试"
    )


router_llm = cheap_chat_model.with_structured_output(SkillRoute)


def select_skill(user_text: str) -> str:
    """
    只选择一个 main_skill。
    """

    prompt = load_router_prompt().format(
        last_msg=user_text,
        main_block=main_block,
        main_names=main_names,
    )

    res = router_llm.invoke(prompt)

    main_skill = res.main_skill.value

    print(f"[Router Reason] {res.reason}")

    return main_skill