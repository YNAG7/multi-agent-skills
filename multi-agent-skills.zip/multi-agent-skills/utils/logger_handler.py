import logging
from utils.path_tool import get_abs_path
import os
from datetime import datetime

LOG_ROOT=  get_abs_path('logs')

os.makedirs(LOG_ROOT, exist_ok=True)

# 日志的格式配置 error info debug
DEFAULT_LOG_FORMAT= logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
)

def get_logger(
    name:str="agent",
    console_level=logging.INFO,
    file_level=logging.DEBUG,
    log_file=None,
)->logging.Logger:
    '''获取日志记录器'''
    logger= logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    
    if logger.handlers:
        return logger
    
    console_handler= logging.StreamHandler()
    console_handler.setLevel(console_level)
    console_handler.setFormatter(DEFAULT_LOG_FORMAT)
    
    logger.addHandler(console_handler)
    
    if log_file is None:
        log_file= os.path.join(LOG_ROOT, f"{name}_{datetime.now().strftime('%Y%m%d')}.log")
    
    file_handler= logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(file_level)
    file_handler.setFormatter(DEFAULT_LOG_FORMAT)
    
    logger.addHandler(file_handler)
    return logger

logger= get_logger()