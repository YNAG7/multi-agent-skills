# skills/registry.py

from __future__ import annotations

import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from utils.path_tool import get_abs_path
from skills.auto_script_loader import load_script_tools,load_common_tools


@dataclass
class SkillSpec:
    name: str
    description: str
    skill_path: str

    # 新增：记录 skill 文件夹路径
    skill_dir: str

    tools: list[Callable] = field(default_factory=list)
    is_workflow: bool = False
    workflow_runner: Optional[Callable] = None
    needs_time_context: bool = False

    _prompt_content: str = field(default="", init=False, repr=False)

    def load_text(self) -> str:
        return self._prompt_content

    def load_runtime_summary(self) -> str:
        text = self._prompt_content
        marker = "# Summary For Runtime"

        if marker not in text:
            return text

        section = text.split(marker, 1)[1]
        next_heading = section.find("\n# ")

        if next_heading != -1:
            section = section[:next_heading]

        return section.strip()

def dedupe_tools(tools: list) -> list:
    seen = set()
    result = []

    for tool in tools:
        name = getattr(tool, "name", None)

        if not name:
            continue

        if name in seen:
            continue

        result.append(tool)
        seen.add(name)

    return result


def build_skill_registry(skills_root: str = "skills") -> dict[str, SkillSpec]:
    """
    自动构建 Skill 注册表。

    功能：
    1. 自动递归扫描 skills/**/SKILL.md
    2. 读取 SKILL.md 的 YAML frontmatter
    3. 自动扫描每个 Skill 目录下的 scripts/*.py
    4. 把 scripts 里的工具注册到对应 Skill
    """
    registry: dict[str, SkillSpec] = {}
    base_path = Path(get_abs_path(skills_root))

    if not base_path.exists():
        return registry
    
    common_tools = load_common_tools()

    for md_file in base_path.rglob("SKILL.md"):
        raw_text = md_file.read_text(encoding="utf-8")

        meta = {}
        content = raw_text

        # 解析 YAML frontmatter
        if raw_text.startswith("---"):
            parts = raw_text.split("---", 2)

            if len(parts) >= 3:
                meta = yaml.safe_load(parts[1]) or {}
                content = parts[2].strip()

        # skill_dir 就是 SKILL.md 所在的文件夹
        skill_dir = md_file.parent

        # 优先使用 YAML 中的 name
        name = meta.get("name", skill_dir.name)

        # 自动扫描该 Skill 下的 scripts
        script_tools = load_script_tools(skill_dir)

        spec = SkillSpec(
            name=name,
            description=meta.get("description", "暂无描述"),
            skill_path=str(md_file),
            skill_dir=str(skill_dir),
            tools=dedupe_tools(script_tools + common_tools),
            is_workflow=meta.get("is_workflow", False),
            needs_time_context=meta.get("needs_time_context", False),
        )

        spec._prompt_content = content

        registry[name] = spec

        print(
            f"[Skill Registry] 已加载 Skill: {name}, "
            f"tools={ [getattr(t, 'name', str(t)) for t in spec.tools] }"
        )

    return registry


# 初始化全局注册表
SKILL_REGISTRY = build_skill_registry()